| `Version` | `Update Notes`                                                                 |
|-----------|--------------------------------------------------------------------------------|
| 1.1.3     | - Update for Valheim 0.217.22                                                  |
| 1.1.2     | - Fix an issue with PerfectPlacement compatibility caused by the Hildir Update |
| 1.1.1     | - Updated for Valheim 0.216.9                                                  |
| 1.0.1     | - Fix the upload. Sorry about that                                             |
| 1.0.0     | - Initial Release                                                              |