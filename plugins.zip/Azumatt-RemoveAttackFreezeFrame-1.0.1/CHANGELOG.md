| `Version` | `Update Notes`                                                                   |
|-----------|----------------------------------------------------------------------------------|
| 1.0.1     | - Courtesy update for Valheim 0.217.22, just compiling against for safe measure. |
| 1.0.0     | - Initial Release                                                                |